local addonName, addon = ...
Guidelime.registerGuide([[
[D*ahmp*'s 12-60 guide]
[GA Alliance]
[N45-45Searing Gorge]
[NX45-46STV/Swamp Late]
run through badlands potential to do whelp heart quest if behind on XP [QS706 Fiery Blaze Enchantments]
[G51.4,76.9Badlands]Turn in [QT687 Theldurin the Lost] 
[G51.4,76.9Badlands]Accept [QA692 The Lost Fragments] 
[G54.7,83.9Badlands]Complete [QC692,1 The Lost Fragments] 
[G51.4,76.9Badlands]Turn in [QT692 The Lost Fragments] 
[G51.4,76.9Badlands]Accept [QA656 Summoning the Princess] 
First on enter Searing Gorge go south and run past all the mobs, accept outhouse quest 
[G72.9,95.9Dun Morogh]Accept [QA4449 Caught!] 
[G72.8,90.5Dun Morogh]Kill [QC4449,1 Dark Iron Geologist] Clear camp[OC]
[G72.1,95.3Dun Morogh]Accept [QA3367 Suntara Stones p1] 
Complete [QC3367 Suntara Stones p1] 
[G76.9,76.4Dun Morogh]Turn in [QT3367 Suntara Stones p1] 
[G76.9,76.4Dun Morogh]Accept [QA3368 Suntara Stones p2] 
[G72.8,90.5Dun Morogh]Kill [QC4449,1 Dark Iron Geologist] 
[G72.9,95.9Dun Morogh]Turn in [QT4449 Caught!] 
[G72.9,95.9Dun Morogh]Accept [QA4450 Ledger from Tanaris] 
[G72.8,95.9Dun Morogh]Complete [QC4450,1 Ledger from Tanaris] 
[G72.9,90.1Dun Morogh]Kill [QC4450,2 Glassweb Spider] Clear the area then go into mountains[OC]
[G72.9,77.7Searing Gorge]Kill Margol the Rager Kite at least 50% she owns
Don't accept the horn quest yet, just hold onto it [QS3181 The Horn of the Beast]
[G72.9,90.1Dun Morogh]Kill [QC4450,2 Glassweb Spider] Finish and wrap towards Thorium Point
Get FP Thorium Point
[F]Fly Ironforge
[G62.6,23.7Dun Morogh]Turn in [QT3368 Suntara Stones p2] 
Tram SW
]],GetAddOnMetadata(addonName, "title"))
local addonName, addon = ...
Guidelime.registerGuide([[
[D*ahmp*'s 12-60 guide]
[GA Alliance]
[N39-39Dustwallow Marsh]
[NX39-40Arathi/Alterac]
[G70.8,79.1The Barrens]Accept [QA1286 The Deserters p1] 
[G69.9,77.5The Barrens]Turn in [QT1260 Morgan Stern] 
[G69.9,77.5The Barrens]Accept [QA1204 Mudrock Soup and Bugs] 
[G67.2,63.5The Barrens]Kill [QC1204,1 Mudrock Spikeshell] Clear up to and around the first island then go inland
[G64.2,67.6The Barrens]Accept [QA1218 Soothing Spices] 
[G64.2,67.6The Barrens]Turn in [QT1218 Soothing Spices] 
[G64.2,67.6The Barrens]Accept [QA1206 Jarl Needs Eyes] 
Accept [QA1219 The Orc Report] dirt mound in yard
Grind to tower close to barrens[OC]
[G54.2,82.1The Barrens]Turn in [QT1286 The Deserters p1] 
[G54.2,82.1The Barrens]Accept [QA1287 The Deserters p2] 
grind north, Hug left mountain to skip past brackenwall village[OC]
[G92.6,74Mulgore]Kill [QC1206,1 Darkmist Silkspinner] Rare in cave
[G59.8,63The Barrens]Accept [QA1222 Stinky's Escape] 
Complete [QC1222 Stinky's Escape] 
[G64.2,67.6The Barrens]Turn in [QT1206 Jarl Needs Eyes] 
[G67.2,63.5The Barrens]Kill [QC1204,1 Mudrock Spikeshell] Need to finish now
[G70.4,79.7The Barrens]Turn in [QT1219 The Orc Report] 
[G70.4,79.7The Barrens]Accept [QA1220 Captain Vimes] 
[G69.9,77.5The Barrens]Turn in [QT1222 Stinky's Escape] Save fortitude elixir
[G69.9,77.5The Barrens]Turn in [QT1204 Mudrock Soup and Bugs] 
[G69.9,77.5The Barrens]Accept [QA1258 ... and Bugs] 
[G70.8,79.1The Barrens]Turn in [QT1220 Captain Vimes] 
Turn in [QT1287 The Deserters p2] 
HS Menethil
[F]Fly Southshore
]],GetAddOnMetadata(addonName, "title"))